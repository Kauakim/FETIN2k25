import '/flutter_flow/flutter_flow_util.dart';
import 'home_mapa_teste_widget.dart' show HomeMapaTesteWidget;
import 'package:flutter/material.dart';

class HomeMapaTesteModel extends FlutterFlowModel<HomeMapaTesteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
