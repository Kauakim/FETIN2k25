var http__client__manager_8c =
[
    [ "_http_event_handler", "http__client__manager_8c.html#ae7c4f5057d30a650919c74c7f9e7d67c", null ],
    [ "http_post_json", "http__client__manager_8c.html#a128db5704dea8a61b6ebfb99c7bac38f", null ]
];