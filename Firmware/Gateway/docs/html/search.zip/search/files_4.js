var searchData=
[
  ['wifi_5fmanager_2ec_0',['wifi_manager.c',['../wifi__manager_8c.html',1,'']]],
  ['wifi_5fmanager_2eh_1',['wifi_manager.h',['../wifi__manager_8h.html',1,'']]]
];
