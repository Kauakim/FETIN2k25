var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../gateway_8h.html#ab898071398b359603a35c202e9c65f3b',1,'gateway.h']]],
  ['_5fhttp_5fevent_5fhandler_1',['_http_event_handler',['../http__client__manager_8c.html#ae7c4f5057d30a650919c74c7f9e7d67c',1,'http_client_manager.c']]]
];
