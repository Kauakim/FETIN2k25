var searchData=
[
  ['scanned_5fbeacon_5fdata_5ft_0',['scanned_beacon_data_t',['../structscanned__beacon__data__t.html',1,'']]]
];
